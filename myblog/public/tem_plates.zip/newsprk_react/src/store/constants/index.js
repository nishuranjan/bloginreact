export const DEFAULT = 'DEFAULT';
export const THROW_ERROR = 'THROW_ERROR';
export const THROW_SUCCESS = 'THROW_SUCCESS';
export const IS_LOADING = 'IS_LOADING';
export const RE_RENDERED = 'RE_RENDERED';